# Gerando de Conjuntos de Dados de classifica��o
# Aron Ifanger Maciel (aronifanger@gmail.com) 
# Ana Carolina Lorena (aclorena@gmail.com)

# Fun��o para gerar a entrada

GeraEntradaClassificacao = function(quantidadeDeLinhas     = 500, 
                       quantidadeDeColunas    = 1)
{
  conjuntoDeEntrada = array(0,c(quantidadeDeLinhas,quantidadeDeColunas))
  
  for(coluna in 1:quantidadeDeColunas)
    conjuntoDeEntrada[,coluna] = runif(quantidadeDeLinhas,min=-1,max=1)
  
  conjuntoDeEntrada
}
