# Gerador de Conjuntos de Dados
# Aron Ifanger Maciel (aronifanger@gmail.com) 
# Ana Carolina Lorena (aclorena@gmail.com)

# Função para gerar a entrada

GeraEntradaRegressao = function(quantidadeDeLinhas     = 500, 
                       quantidadeDeColunas    = 1)
{
  conjuntoDeEntrada = array(0,c(quantidadeDeLinhas,quantidadeDeColunas))
  
  for(coluna in 1:quantidadeDeColunas)
    conjuntoDeEntrada[,coluna] = runif(quantidadeDeLinhas,min=-1,max=1)
  
  conjuntoDeEntrada
}
