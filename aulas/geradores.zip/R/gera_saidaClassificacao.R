# Gerador de Conjuntos de Dados de classificação
# Aron Ifanger Maciel (aronifanger@gmail.com)
# Ana Carolina Lorena (aclorena@gmail.com)

# Função para gerar a saída

GeraSaidaClassificacao = function(x,
                     funcao = "pol1",erro)
{
  quantidadeDeLinhas  = nrow(x)
  quantidadeDeColunas = ncol(x)
  
  if(funcao == "pol1"){
    qd = quantidadeDeColunas-1
    a = t(array(runif(qd,min=-2,max=2),
                c(qd,quantidadeDeLinhas)))
    x1 = t(array(runif(qd,min=-1,max=1),c(qd,quantidadeDeLinhas)))
    y <- apply(a*(x[,1:qd]-x1),1,sum)
  } 
  else if(funcao == "pol2"){
    qd = quantidadeDeColunas-1
    a = t(array(runif(qd,min=-2,max=2),c(qd,quantidadeDeLinhas)))
    x1 = t(array(runif(qd,min=-1,max=1)*0.7,c(qd,quantidadeDeLinhas)))
    x2 = t(array(runif(qd,min=-1,max=1)*1.4,c(qd,quantidadeDeLinhas)))
    y <- apply(a*(x[,1:qd]-x1)*(x[,1:qd]-x2),1,sum)
  } 
  else if(funcao == "pol3"){
    qd = quantidadeDeColunas-1
    a = t(array(runif(qd,min=-2,max=2),c(qd,quantidadeDeLinhas)))
    x1 = t(array(runif(qd,min=-1,max=1)*0.5,c(qd,quantidadeDeLinhas)))
    x2 = t(array(runif(qd,min=-1,max=1)*1.0,c(qd,quantidadeDeLinhas)))
    x3 = t(array(runif(qd,min=-1,max=1)*1.5,c(qd,quantidadeDeLinhas)))
    y <- apply(a*(x[,1:qd]-x1)*(x[,1:qd]-x2)*(x[,1:qd]-x3),1,sum)
  }
  else if(funcao == "pol4"){
    qd = quantidadeDeColunas-1
    a = t(array(runif(qd,min=-2,max=2),c(qd,quantidadeDeLinhas)))
    x1 = t(array(runif(qd,min=-1,max=1)*0.4,c(qd,quantidadeDeLinhas)))
    x2 = t(array(runif(qd,min=-1,max=1)*0.8,c(qd,quantidadeDeLinhas)))
    x3 = t(array(runif(qd,min=-1,max=1)*1.2,c(qd,quantidadeDeLinhas)))
    x4 = t(array(runif(qd,min=-1,max=1)*1.6,c(qd,quantidadeDeLinhas)))
    y <- apply(a*(x[,1:qd]-x1)*(x[,1:qd]-x2)*(x[,1:qd]-x3)*(x[,1:qd]-x4),1,sum)
  } 
  else if(funcao == "pol5"){
    qd = quantidadeDeColunas-1
    a = t(array(runif(qd,min=-2,max=2),c(qd,quantidadeDeLinhas)))
    x1 = t(array(runif(qd,min=-1,max=1)*0.3,c(qd,quantidadeDeLinhas)))
    x2 = t(array(runif(qd,min=-1,max=1)*0.7,c(qd,quantidadeDeLinhas)))
    x3 = t(array(runif(qd,min=-1,max=1)*1.1,c(qd,quantidadeDeLinhas)))
    x4 = t(array(runif(qd,min=-1,max=1)*1.4,c(qd,quantidadeDeLinhas)))
    x5 = t(array(runif(qd,min=-1,max=1)*1.7,c(qd,quantidadeDeLinhas)))
    y <- apply(a*(x[,1:qd]-x1)*(x[,1:qd]-x2)*(x[,1:qd]-x3)*(x[,1:qd]-x4)*(x[,1:qd]-x5),1,sum)
  }
  else if(funcao == "sin1"){
    qd = quantidadeDeColunas-1
    fase = t(array(runif(qd,min=-1,max=1),c(qd,quantidadeDeLinhas)))
    y = apply(runif(1)*sin(x[,1:qd]*pi*2 + fase),1,sum)
  }
  else if(funcao == "sin2"){
    qd = quantidadeDeColunas-1
    fase = t(array(runif(qd,min=-1,max=1),
                   c(qd,quantidadeDeLinhas)))
    y = apply(runif(1)*sin(x[,1:qd]*pi*4 + fase),1,sum)
  } 
  else if(funcao == "sin3"){
    qd = quantidadeDeColunas-1
    fase = t(array(runif(qd,min=-1,max=1),
                   c(qd,quantidadeDeLinhas)))
    y = apply(runif(1)*sin(x[,1:qd]*pi*6 + fase),1,sum)
  } 
  
  y = y + rnorm(quantidadeDeLinhas,sd=erro)
  y <- as.factor(x[,quantidadeDeColunas]>y)  
  
  list(saida = y)
}