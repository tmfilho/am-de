# Gerador de Conjuntos de Dados de regress�o
# Aron Ifanger Maciel (aronifanger@gmail.com) 
# Ana Carolina Lorena (aclorena@gmail.com)

# Função para gerar a saída

GeraSaidaRegressao = function(x,
                     erro = 0.1,
                     funcao = "pol1")
{
  quantidadeDeLinhas  = nrow(x)
  quantidadeDeColunas = ncol(x)
  
  if(funcao == "pol1"){
    a = t(array(runif(quantidadeDeColunas,min=-2,max=2),
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x1 = t(array(runif(quantidadeDeColunas,min=-1,max=1),
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    y = apply(a*(x-x1),1,sum)
  }else if(funcao == "pol2"){
    a = t(array(runif(quantidadeDeColunas,min=-2,max=2),
                c(quantidadeDeColunas,quantidadeDeLinhas)))
    x1 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*0.7,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x2 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*1.4,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    y = apply(a*(x-x1)*(x-x2),1,sum)
  }
  else if(funcao == "pol3"){
    a = t(array(runif(quantidadeDeColunas,min=-2,max=2),
                c(quantidadeDeColunas,quantidadeDeLinhas)))
    x1 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*0.5,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x2 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*1,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x3 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*1.5,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    y = apply(a*(x-x1)*(x-x2)*(x-x3),1,sum)
  } else if(funcao == "pol4"){
    a = t(array(runif(quantidadeDeColunas,min=-2,max=2),
                c(quantidadeDeColunas,quantidadeDeLinhas)))
    x1 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*0.4,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x2 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*0.8,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x3 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*1.2,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x4 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*1.6,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    y = apply(a*(x-x1)*(x-x2)*(x-x3)*(x-x4),1,sum)
  }
  else if(funcao == "pol5"){
    a = t(array(runif(quantidadeDeColunas,min=-2,max=2),
                c(quantidadeDeColunas,quantidadeDeLinhas)))
    x1 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*0.3,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x2 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*0.7,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x3 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*1.1,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x4 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*1.4,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    x5 = t(array(runif(quantidadeDeColunas,min=-1,max=1)*1.7,
                 c(quantidadeDeColunas,quantidadeDeLinhas)))
    y = apply(a*(x-x1)*(x-x2)*(x-x3)*(x-x4)*(x-x5),1,sum)
  }
  else if(funcao == "sin1"){
    fase = t(array(runif(quantidadeDeColunas)*pi*2,
                   c(quantidadeDeColunas,quantidadeDeLinhas)))
    y = apply(runif(1)*sin(x*pi*2 + fase),1,sum)
  }
  else if(funcao == "sin2"){
    fase = t(array(runif(quantidadeDeColunas)*pi*2,
                   c(quantidadeDeColunas,quantidadeDeLinhas)))
    y = apply(runif(1)*sin(x*pi*4 + fase),1,sum)
    
  }
  else if(funcao == "sin3"){
    fase = t(array(runif(quantidadeDeColunas)*pi*2,
                   c(quantidadeDeColunas,quantidadeDeLinhas)))
    y = apply(runif(1)*sin(x*pi*6 + fase),1,sum)
  } 
  y = y + rnorm(quantidadeDeLinhas,sd=erro)
  list(saida = y)
}