# Gerandor de Conjuntos de Dados de regress?o
# Aron Ifanger Maciel (aronifanger@gmail.com) 
# Ana Carolina Lorena (aclorena@gmail.com)

GeraConjuntoRegressao = function(nome,
                        quantidadeDeLinhas, # sugestão: 1000
                        quantidadeDeColunas, # sugestão: 2
                        funcao, # opções: 'pol1', 'pol2', 'pol3', 'pol4', 'pol5', 'sin1', 'sin2', 'sin3'
                        erro ) # sugestão: 0.1
{
  x = GeraEntradaRegressao(quantidadeDeLinhas, quantidadeDeColunas)
  
  saida = GeraSaidaRegressao(x,erro,funcao)
  y = saida$saida
  #write.csv(cbind(x,y),nome)
  return(as.data.frame(cbind(x,y)))
}

