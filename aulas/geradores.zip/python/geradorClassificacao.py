# Gerando de Conjuntos de Dados de classificação
# Aron Ifanger Maciel (aronifanger@gmail.com)
# Ana Carolina Lorena (aclorena@gmail.com)

import pandas as pd

from gera_entradaClassificacao import gera_entrada_classificacao
from gera_saidaClassificacao import gera_saida_classificacao

def gera_conjunto_classificacao(
    nome,
    quantidade_de_linhas,  # sugestão: 1000
    quantidade_de_colunas,  # sugestão: 2
    funcao,  # opções: 'pol1', 'pol2', 'pol3', 'pol4', 'pol5', 'sin1', 'sin2', 'sin3'
    erro,  # sugestão: 0.1
    include_last=True
):
    x = gera_entrada_classificacao(
        quantidade_de_linhas, 
        quantidade_de_colunas
    )
    saida = gera_saida_classificacao(x, erro, funcao, include_last=include_last)
    df = pd.DataFrame(
        x,
        columns=['V{}'.format(i+1) for i in range(x.shape[1])]
    )
    df['y'] = saida['saida']
    # df.to_csv(nome)
    return df
