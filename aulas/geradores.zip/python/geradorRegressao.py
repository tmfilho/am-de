# Gerador de Conjuntos de Dados de regress�o
# Aron Ifanger Maciel (aronifanger@gmail.com) 
# Ana Carolina Lorena (aclorena@gmail.com)

import pandas as pd

from gera_entradaRegressao import gera_entrada_regressao
from gera_saidaRegressao import gera_saida_regressao

def gera_conjunto_regressao(
    nome,
    quantidade_de_linhas,   # sugestão: 1000
    quantidade_de_colunas,   # sugestão: 2
    funcao,   # opções: 'pol1', 'pol2', 'pol3', 'pol4', 'pol5', 'sin1', 'sin2', 'sin3'
    erro   # sugestão: 0.1
):
    x = gera_entrada_regressao(
        quantidade_de_linhas, 
        quantidade_de_colunas
    )
    saida = gera_saida_regressao(x, erro, funcao)
    df = pd.DataFrame(
        x,
        columns=['V{}'.format(i+1) for i in range(x.shape[1])]
    )
    df['y'] = saida['saida']
    # df.to_csv(nome)
    return df

